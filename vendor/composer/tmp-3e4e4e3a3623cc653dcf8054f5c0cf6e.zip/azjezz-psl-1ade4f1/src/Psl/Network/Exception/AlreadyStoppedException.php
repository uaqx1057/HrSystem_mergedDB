<?php

declare(strict_types=1);

namespace Psl\Network\Exception;

final class AlreadyStoppedException extends RuntimeException
{
}
