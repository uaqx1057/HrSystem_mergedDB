<?php

namespace Vonage\Messages\Channel\Messenger;

class InvalidCategoryException extends \Exception
{
}
