<?php
namespace Edujugon\PushNotification\Exceptions;

class PushNotificationException extends \Exception
{

}
