<?php

namespace Vonage\Messages\Channel\RCS;

class RcsInvalidTtlException extends \Exception
{
}
