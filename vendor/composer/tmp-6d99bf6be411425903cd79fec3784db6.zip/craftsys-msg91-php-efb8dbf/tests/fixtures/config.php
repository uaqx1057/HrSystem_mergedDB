<?php
return [
    'token' => '<your_token_here>',
    "otp_message" => "Your verification code is ##OTP##",
    "retry_via" => "voice",
    "country" => null,
    "from" => null,
];
