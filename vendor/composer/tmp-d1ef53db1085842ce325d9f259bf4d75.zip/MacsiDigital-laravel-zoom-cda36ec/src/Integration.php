<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\API\Support\Resource;

class Integration extends Resource
{
}
