---
home: true
heroImage: https://flutterwave.com/images/graph/home.png
tagline: A Laravel package that makes it easy to use Flutterwave APIs
actionText: Get Started →
actionLink: /getting-started/installation.html
# features:
# - title: Feature 1 Title
#   details: Feature 1 Description
# - title: Feature 2 Title
#   details: Feature 2 Description
# - title: Feature 3 Title
#   details: Feature 3 Description
footer: Made by Oluwole Adebiyi (Kingflamez) with ❤️
---
