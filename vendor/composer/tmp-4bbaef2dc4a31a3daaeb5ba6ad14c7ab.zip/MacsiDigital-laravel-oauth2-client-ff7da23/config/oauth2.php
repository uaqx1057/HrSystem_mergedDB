<?php

return [
    'table_name' => 'integrations',
];
