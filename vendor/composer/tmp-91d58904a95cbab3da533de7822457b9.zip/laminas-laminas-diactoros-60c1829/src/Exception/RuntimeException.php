<?php

declare(strict_types=1);

namespace Laminas\Diactoros\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
