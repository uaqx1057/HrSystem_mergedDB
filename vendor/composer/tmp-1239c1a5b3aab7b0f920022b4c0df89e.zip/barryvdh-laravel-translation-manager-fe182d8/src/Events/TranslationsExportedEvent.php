<?php
/**
 * Created by PhpStorm.
 * User: kgbot
 * Date: 5/29/18
 * Time: 12:40 PM
 */

namespace Barryvdh\TranslationManager\Events;


class TranslationsExportedEvent
{

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct()
    {

    }
}