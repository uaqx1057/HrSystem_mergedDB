<?php

namespace Yandex\Translate;

/**
 * Exception
 * @author Nikita Gusakov <dev@nkt.me>
 */
class Exception extends \Exception
{

} 
