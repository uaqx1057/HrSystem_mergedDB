<?php

declare(strict_types=1);

namespace Vonage\Voice\Call;

/**
 * @deprecated This objects are no longer viable and will be removed in a future version
 */
class Inbound
{
}
