<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\API\Support\Resource;

class InMeeting extends Resource
{
}
