This repository has [guidelines specific to testing][testing guidelines], and
Doctrine has [general contributing guidelines][contributor workflow], make
sure you follow both.

[contributor workflow]: https://www.doctrine-project.org/contribute/index.html
[testing guidelines]: https://www.doctrine-project.org/projects/doctrine-dbal/en/stable/reference/testing.html
