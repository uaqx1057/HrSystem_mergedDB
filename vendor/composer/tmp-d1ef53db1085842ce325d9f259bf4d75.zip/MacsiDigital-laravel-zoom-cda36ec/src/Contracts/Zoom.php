<?php

namespace MacsiDigital\Zoom\Contracts;

use MacsiDigital\API\Facades\Client as ClientFacade;

interface Zoom extends ClientFacade
{
}
