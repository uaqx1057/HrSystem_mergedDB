<?php

namespace MacsiDigital\OAuth2\Contracts;

interface Connection
{
}
