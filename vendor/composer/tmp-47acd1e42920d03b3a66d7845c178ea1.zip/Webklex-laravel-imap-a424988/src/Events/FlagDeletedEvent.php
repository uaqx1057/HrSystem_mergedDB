<?php

namespace Webklex\IMAP\Events;


class FlagDeletedEvent extends FlagNewEvent {

}
