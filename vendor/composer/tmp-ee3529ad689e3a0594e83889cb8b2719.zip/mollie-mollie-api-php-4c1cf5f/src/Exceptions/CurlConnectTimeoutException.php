<?php

namespace Mollie\Api\Exceptions;

class CurlConnectTimeoutException extends ApiException
{
}
