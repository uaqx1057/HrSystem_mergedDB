<?php
/*
* File:     FlagDeletedEvent.php
* Category: Event
* Author:   M. Goldenbaum
* Created:  25.11.20 22:21
* Updated:  -
*
* Description:
*  -
*/

namespace Webklex\PHPIMAP\Events;

/**
 * Class FlagDeletedEvent
 *
 * @package Webklex\PHPIMAP\Events
 */
class FlagDeletedEvent extends FlagNewEvent {

}
