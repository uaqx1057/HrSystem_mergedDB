<?php

namespace Sentry\Laravel;

final class Version
{
    public const SDK_IDENTIFIER = 'sentry.php.laravel';
    public const SDK_VERSION = '4.20.1';
}
