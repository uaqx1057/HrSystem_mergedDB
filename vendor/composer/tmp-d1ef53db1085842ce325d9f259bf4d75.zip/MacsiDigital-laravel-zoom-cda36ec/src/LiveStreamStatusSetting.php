<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\Zoom\Support\Resource;

class LiveStreamStatusSetting extends Resource
{
}
