<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Text extends Field
{
}
