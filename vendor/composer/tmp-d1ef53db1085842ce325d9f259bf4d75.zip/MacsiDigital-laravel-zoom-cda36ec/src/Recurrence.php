<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\API\Support\Resource;

class Recurrence extends Resource
{
    protected $updateOnlyDirty = false;
}
