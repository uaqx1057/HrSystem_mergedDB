<?php

declare(strict_types=1);

namespace Psl\Async\Exception;

final class ResourceClosedException extends RuntimeException
{
}
