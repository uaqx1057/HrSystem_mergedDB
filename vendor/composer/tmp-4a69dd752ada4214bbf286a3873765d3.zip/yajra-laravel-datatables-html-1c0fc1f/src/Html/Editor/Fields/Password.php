<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Password extends Field
{
    protected string $type = 'password';
}
