<?php

namespace Amp\Process;

class StatusError extends \Error
{
}
