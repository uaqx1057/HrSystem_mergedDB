<?php
namespace MacsiDigital\API\Support;

use MacsiDigital\API\Traits\InteractsWithAPI;

class ApiResource extends Resource
{
    use InteractsWithAPI;
}
