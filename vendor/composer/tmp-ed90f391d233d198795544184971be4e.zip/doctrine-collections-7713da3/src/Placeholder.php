<?php

declare(strict_types=1);

namespace Doctrine\Common\Collections;

/** @internal */
enum Placeholder
{
    case NotSpecified;
}
