<?php

namespace MacsiDigital\Zoom\Requests;

use MacsiDigital\API\Support\PersistResource;

class UpdateAccount extends PersistResource
{
    protected $persistAttributes = [
        
    ];
}
