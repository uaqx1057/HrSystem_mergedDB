<?php

namespace MacsiDigital\API\Exceptions;

class NodeNotFoundException extends Base
{
}
