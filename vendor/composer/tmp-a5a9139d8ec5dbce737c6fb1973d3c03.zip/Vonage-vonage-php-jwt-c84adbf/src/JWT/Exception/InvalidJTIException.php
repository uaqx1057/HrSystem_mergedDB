<?php
declare(strict_types=1);

namespace Vonage\JWT\Exception;

class InvalidJTIException extends \InvalidArgumentException
{

}
