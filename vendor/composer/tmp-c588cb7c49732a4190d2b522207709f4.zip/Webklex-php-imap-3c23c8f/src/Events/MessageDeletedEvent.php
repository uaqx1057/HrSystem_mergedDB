<?php
/*
* File:     MessageDeletedEvent.php
* Category: Event
* Author:   M. Goldenbaum
* Created:  25.11.20 22:21
* Updated:  -
*
* Description:
*  -
*/

namespace Webklex\PHPIMAP\Events;

/**
 * Class MessageDeletedEvent
 *
 * @package Webklex\PHPIMAP\Events
 */
class MessageDeletedEvent extends MessageNewEvent {

}
