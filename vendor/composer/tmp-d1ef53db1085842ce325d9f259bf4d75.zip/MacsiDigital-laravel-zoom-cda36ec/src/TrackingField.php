<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\API\Support\Resource;

class TrackingField extends Resource
{
}
