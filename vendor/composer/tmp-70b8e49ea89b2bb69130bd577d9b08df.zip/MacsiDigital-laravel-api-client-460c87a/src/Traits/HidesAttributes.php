<?php

namespace MacsiDigital\API\Traits;

use Illuminate\Database\Eloquent\Concerns\HidesAttributes as LaravelHidesAttributes;

trait HidesAttributes
{
    use LaravelHidesAttributes;
}
