<?php
/*
* File:     MessageRestoredEvent.php
* Category: Event
* Author:   M. Goldenbaum
* Created:  25.11.20 22:21
* Updated:  -
*
* Description:
*  -
*/

namespace Webklex\PHPIMAP\Events;

/**
 * Class MessageRestoredEvent
 *
 * @package Webklex\PHPIMAP\Events
 */
class MessageRestoredEvent extends MessageNewEvent {

}
