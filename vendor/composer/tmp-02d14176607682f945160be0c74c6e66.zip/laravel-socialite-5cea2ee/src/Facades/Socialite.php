<?php

namespace Laravel\Socialite\Facades;

use Laravel\Socialite\Socialite as SocialiteFacade;

class Socialite extends SocialiteFacade
{
}
