<?php

namespace Webklex\IMAP\Events;


class MessageDeletedEvent extends MessageNewEvent {

}
