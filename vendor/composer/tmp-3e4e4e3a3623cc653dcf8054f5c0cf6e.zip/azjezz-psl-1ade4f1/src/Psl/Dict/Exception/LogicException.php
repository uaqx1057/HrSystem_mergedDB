<?php

declare(strict_types=1);

namespace Psl\Dict\Exception;

use Psl\Exception;

final class LogicException extends Exception\LogicException implements ExceptionInterface
{
}
