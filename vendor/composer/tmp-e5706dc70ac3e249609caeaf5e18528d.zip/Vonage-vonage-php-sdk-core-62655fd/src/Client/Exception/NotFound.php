<?php

declare(strict_types=1);

namespace Vonage\Client\Exception;

class NotFound extends \Exception
{
}
