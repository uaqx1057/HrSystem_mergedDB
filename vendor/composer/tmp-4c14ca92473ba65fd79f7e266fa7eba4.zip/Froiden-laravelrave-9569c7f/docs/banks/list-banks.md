# List Banks

This helps you fetch banks with their code

## Get Nigerian Banks

```php
<?php

$banks = Flutterwave::banks()->nigeria();

dd($banks);

```

## Get Ghanaian Banks

```php
<?php

$banks = Flutterwave::banks()->ghana();

dd($banks);

```

## Get Kenyan Banks

```php
<?php

$banks = Flutterwave::banks()->kenya();

dd($banks);

```

## Get Ugandan Banks

```php
<?php

$banks = Flutterwave::banks()->uganda();

dd($banks);

```

## Get South African Banks

```php
<?php

$banks = Flutterwave::banks()->southAfrica();

dd($banks);

```

## Get Tanzanian Banks

```php
<?php

$banks = Flutterwave::banks()->tanzania();

dd($banks);

```
