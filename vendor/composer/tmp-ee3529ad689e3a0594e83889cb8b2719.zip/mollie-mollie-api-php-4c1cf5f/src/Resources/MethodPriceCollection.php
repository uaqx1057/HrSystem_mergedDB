<?php

namespace Mollie\Api\Resources;

class MethodPriceCollection extends BaseCollection
{
    /**
     * @return string|null
     */
    public function getCollectionResourceName()
    {
        return null;
    }
}
