<?php

return [
    'api' => [
        'base_url' => 'http://playground.test/api/',
        'options' => [

        ],
    ],
];
