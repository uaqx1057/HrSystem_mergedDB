<?php

declare(strict_types=1);

namespace Vonage\Insights;

class AdvancedCnam extends Advanced
{
    use CnamTrait;
}
