# Security Checker

The SensioLabs Security Checker API is abandoned

You can use one of following tasks as a replacement:

- [securitychecker_enlightn](securitychecker/enlightn.md)
- [securitychecker_local](securitychecker/local.md)
- [securitychecker_roave](securitychecker/roave.md)
- [securitychecker_symfony](securitychecker/symfony.md)
