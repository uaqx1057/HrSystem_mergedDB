<?php

declare(strict_types=1);

namespace GrumPHP\Exception;

interface ExceptionInterface
{
}
