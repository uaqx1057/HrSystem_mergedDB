<?php
namespace MacsiDigital\OAuth2\Support\Providers;

use \League\OAuth2\Client\Provider\GenericProvider as LeagueGenericProvider;

class GenericProvider extends LeagueGenericProvider
{
}
