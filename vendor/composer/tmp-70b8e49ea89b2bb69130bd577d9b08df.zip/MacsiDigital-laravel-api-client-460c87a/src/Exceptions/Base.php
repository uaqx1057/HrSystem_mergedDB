<?php

namespace MacsiDigital\API\Exceptions;

use Exception;

class Base extends Exception
{
}
