<?php

declare(strict_types=1);

namespace Vonage\Client\Callback;

interface CallbackInterface
{
    public function getData();
}
