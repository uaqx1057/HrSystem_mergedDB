<?php

namespace MacsiDigital\Zoom\Requests;

use MacsiDigital\API\Support\PersistResource;

class StoreAccount extends PersistResource
{
    protected $persistAttributes = [
        
    ];
}
