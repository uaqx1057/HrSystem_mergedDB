<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\API\Support\Resource;

class PollQuestion extends Resource
{
}
