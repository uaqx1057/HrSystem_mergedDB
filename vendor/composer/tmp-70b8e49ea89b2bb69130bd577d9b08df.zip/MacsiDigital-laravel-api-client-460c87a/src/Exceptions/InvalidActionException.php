<?php

namespace MacsiDigital\API\Exceptions;

use Exception;

class InvalidActionException extends Exception
{
    //
}
