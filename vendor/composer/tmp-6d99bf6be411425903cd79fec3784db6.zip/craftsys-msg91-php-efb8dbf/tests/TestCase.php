<?php

namespace Craftsys\Tests\Msg91;

use PHPUnit\Framework\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{ }
