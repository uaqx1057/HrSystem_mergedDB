<?php
return [
    "text1" => "Tidpunkterna måste vara i formatet hh:mm! ",
    "text2" => ":name har redan attesterat denna månad!",
    "text3" => "Detta krockar med en registrering som :name har gjort mellan klockan :from och :to samma dag!",
    "text4" => "Grattis, du hade rätt på :percent% av frågorna på första försöket!",
    "text5" => "(Ange :alternatives alternativ)",
];
