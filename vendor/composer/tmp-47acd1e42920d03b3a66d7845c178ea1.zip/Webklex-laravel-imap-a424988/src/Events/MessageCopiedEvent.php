<?php

namespace Webklex\IMAP\Events;

use Webklex\PHPIMAP\Message;

class MessageCopiedEvent extends MessageMovedEvent {

}
