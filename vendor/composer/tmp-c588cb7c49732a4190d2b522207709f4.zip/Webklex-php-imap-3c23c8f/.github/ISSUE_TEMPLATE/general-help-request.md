---
name: General help request
about: Feel free to ask about any project related stuff

---

Please be aware that these issues will be closed if inactive for more then 14 days.

Also make sure to use https://github.com/Webklex/php-imap/issues/new?template=bug_report.md if you want to report a bug 
or https://github.com/Webklex/php-imap/issues/new?template=feature_request.md if you want to suggest a feature.

Still here? Well clean this out and go ahead :)
