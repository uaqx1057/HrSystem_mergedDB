<?php

declare(strict_types=1);

namespace Psl\Async\Exception;

use Psl\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
