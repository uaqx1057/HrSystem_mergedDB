<?php

declare(strict_types=1);

namespace Vonage\Entity\Filter;

interface FilterInterface
{
    public function getQuery();
}
