<?php

namespace Webklex\IMAP\Events;


class MessageRestoredEvent extends MessageNewEvent {

}
