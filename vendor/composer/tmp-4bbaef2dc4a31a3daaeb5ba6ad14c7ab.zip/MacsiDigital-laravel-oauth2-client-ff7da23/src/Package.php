<?php

namespace MacsiDigital\OAuth2;

class Package
{
    const VERSION = '1.1.1';

    public function version()
    {
        return self::VERSION;
    }
}
