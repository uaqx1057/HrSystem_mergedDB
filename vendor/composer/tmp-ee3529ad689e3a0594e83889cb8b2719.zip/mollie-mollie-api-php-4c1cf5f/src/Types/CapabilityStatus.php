<?php

namespace Mollie\Api\Types;

class CapabilityStatus
{
    public const ENABLED = 'enabled';
    public const PENDING = 'pending';
    public const DISABLED = 'disabled';
}
