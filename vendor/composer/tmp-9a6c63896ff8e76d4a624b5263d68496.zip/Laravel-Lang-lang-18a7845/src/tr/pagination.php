<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Sayfalama Dil Satırları
    |--------------------------------------------------------------------------
    |
    | Aşağıdaki dil satırları sayfalandırma kütüphanesi tarafından basit sayfalandırma
    | bağlantıları oluşturmak için kullanılır. Bu satırları uygulamanızın tasarımsal
    | ihtiyaçları ile eşleşecek şekilde, dilediğiniz gibi, değiştirebilirsiniz.
    |
    */

    'previous' => '&laquo; Öncekiler',
    'next'     => 'Sonrakiler &raquo;',

];
