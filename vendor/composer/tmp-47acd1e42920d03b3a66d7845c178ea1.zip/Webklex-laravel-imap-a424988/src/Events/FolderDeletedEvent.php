<?php

namespace Webklex\IMAP\Events;

class FolderDeletedEvent extends FolderNewEvent {

}
