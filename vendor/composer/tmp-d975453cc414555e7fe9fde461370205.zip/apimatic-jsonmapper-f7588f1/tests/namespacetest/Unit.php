<?php
namespace namespacetest;

class Unit
{
    public $value;
}
?>
