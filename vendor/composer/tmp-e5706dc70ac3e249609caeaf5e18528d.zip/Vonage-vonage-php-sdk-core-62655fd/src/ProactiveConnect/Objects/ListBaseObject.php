<?php

namespace Vonage\ProactiveConnect\Objects;

abstract class ListBaseObject
{
}
