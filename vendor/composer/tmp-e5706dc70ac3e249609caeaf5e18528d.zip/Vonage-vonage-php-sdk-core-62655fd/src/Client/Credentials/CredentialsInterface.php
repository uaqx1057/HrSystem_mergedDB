<?php

declare(strict_types=1);

namespace Vonage\Client\Credentials;

interface CredentialsInterface
{
    public function asArray();
}
