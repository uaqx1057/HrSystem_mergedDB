<?php

namespace Gitonomy\Git\Exception;

class RuntimeException extends \RuntimeException implements GitExceptionInterface
{
}
