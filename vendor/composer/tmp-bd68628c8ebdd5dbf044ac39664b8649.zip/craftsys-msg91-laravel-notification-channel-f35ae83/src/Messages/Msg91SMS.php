<?php

namespace Craftsys\Notifications\Messages;

use Craftsys\Msg91\SMS\Options;

/**
 * SMS message
 */
class Msg91SMS extends Options
{
}
