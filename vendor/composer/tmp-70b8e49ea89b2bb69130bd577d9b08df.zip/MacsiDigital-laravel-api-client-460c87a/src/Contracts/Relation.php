<?php

namespace MacsiDigital\API\Contracts;

interface Relation
{
}
