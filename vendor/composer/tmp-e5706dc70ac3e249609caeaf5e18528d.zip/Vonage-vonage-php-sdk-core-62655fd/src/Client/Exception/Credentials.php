<?php

declare(strict_types=1);

namespace Vonage\Client\Exception;

class Credentials extends \Exception
{
}
