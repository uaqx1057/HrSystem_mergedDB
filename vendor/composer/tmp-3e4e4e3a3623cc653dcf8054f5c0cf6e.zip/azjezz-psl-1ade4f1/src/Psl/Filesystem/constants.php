<?php

declare(strict_types=1);

namespace Psl\Filesystem;

use const DIRECTORY_SEPARATOR;

/**
 * @var non-empty-string
 */
const SEPARATOR = DIRECTORY_SEPARATOR;
