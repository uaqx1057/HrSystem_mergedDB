<?php

declare(strict_types=1);

namespace Psl\Exception;

final class InvariantViolationException extends RuntimeException
{
}
