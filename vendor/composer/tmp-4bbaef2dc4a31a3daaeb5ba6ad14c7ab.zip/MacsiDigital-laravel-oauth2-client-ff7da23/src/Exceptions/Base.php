<?php

namespace MacsiDigital\OAuth2\Exceptions;

use Exception;

class Base extends Exception
{
}
