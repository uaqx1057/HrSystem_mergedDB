<?php

namespace MacsiDigital\Zoom\Support;

use Illuminate\Http\Client\Factory;

class Client extends Factory
{
}
