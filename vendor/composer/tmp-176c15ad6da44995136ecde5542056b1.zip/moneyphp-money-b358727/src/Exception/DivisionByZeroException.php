<?php

declare(strict_types=1);

namespace Money\Exception;

final class DivisionByZeroException extends InvalidArgumentException
{
}
