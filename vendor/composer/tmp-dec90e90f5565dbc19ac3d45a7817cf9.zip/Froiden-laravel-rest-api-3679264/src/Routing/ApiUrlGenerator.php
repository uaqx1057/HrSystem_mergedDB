<?php

namespace Froiden\RestAPI\Routing;

class ApiUrlGenerator extends \Illuminate\Routing\UrlGenerator
{

}