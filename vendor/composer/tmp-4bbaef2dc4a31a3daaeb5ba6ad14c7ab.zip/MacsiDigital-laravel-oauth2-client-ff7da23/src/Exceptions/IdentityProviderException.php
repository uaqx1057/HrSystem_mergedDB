<?php

namespace MacsiDigital\OAuth2\Exceptions;

use \League\OAuth2\Client\Provider\Exception\IdentityProviderException as LeagueException;

class IdentityProviderException extends LeagueException
{
}
