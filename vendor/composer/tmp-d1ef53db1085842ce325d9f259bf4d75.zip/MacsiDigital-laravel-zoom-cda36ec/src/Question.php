<?php

namespace MacsiDigital\Zoom;

use MacsiDigital\API\Support\Resource;

class Question extends Resource
{
}
